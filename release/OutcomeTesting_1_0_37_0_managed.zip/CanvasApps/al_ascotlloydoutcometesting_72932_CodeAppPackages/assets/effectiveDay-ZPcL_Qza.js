function t(){return new Date().toISOString().slice(0,10)}export{t};
